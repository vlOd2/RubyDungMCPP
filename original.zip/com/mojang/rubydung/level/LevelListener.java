package com.mojang.rubydung.level;

public interface LevelListener {
	void tileChanged(int i1, int i2, int i3);

	void lightColumnChanged(int i1, int i2, int i3, int i4);

	void allChanged();
}
